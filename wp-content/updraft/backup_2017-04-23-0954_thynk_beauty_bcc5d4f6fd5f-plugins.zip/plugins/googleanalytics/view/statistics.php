<div class="wrap ga-wrap">
    <h2>Google Analytics - <?php _e( 'Dashboard' ); ?></h2>
    <div class="ga_container" id="exTab2">
		<?php echo $data ?>
    </div>
</div>